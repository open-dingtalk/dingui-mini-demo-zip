import colorStyle from './color-style.json';

Page({
  data: {
    colorStyle,
  },
  onLoad() {

  },
  
  toHome() {
    dd.navigateTo({
      url: '/src/demo/index/index'
    })
  },
});
