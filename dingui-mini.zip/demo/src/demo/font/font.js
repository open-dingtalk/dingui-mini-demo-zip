import fontStyle from './font-style.json';

Page({
  data: {
    fontStyle,
  },
  onLoad() {},
  toHome() {
    dd.navigateTo({
      url: '/src/demo/index/index'
    })
  },
});
