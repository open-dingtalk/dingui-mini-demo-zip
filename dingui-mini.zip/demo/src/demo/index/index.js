import demoList from './page.js';

Page({
  data: {
    showState: {},
    demoList
  },
  onTitleTap(id,e,comp) {
    const key = `showState[${id}]`;
    this.setData({
      [key]: !this.data.showState[id]
    })
  },
  toAbout() {
    dd.navigateTo({
      url: '/src/demo/about/about'
    })
  },
  onLineTap(id,e,comp) {
    dd.navigateTo({
      url: id
    })
  },
  onShareAppMessage() {
    return {
      title: 'dingui-mini组件库',
      desc: 'dingui-mini是一套遵循钉钉设计规范的组件库，涵盖基础组件和业务组件，由钉钉官方为钉钉小程序量身设计，让用户的体验和感知统一。',
      path: '/src/demo/index/index'
    };
  },
});