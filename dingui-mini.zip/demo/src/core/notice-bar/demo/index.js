
Component({
  mixins: [],
  data: {
    $uiName: 'notice-bar',
    showNotice: true,
  },
  props: {
    className: '',
    type: 'info', // ['info', 'alert', 'warn']兼容mini-ddui
    value: '',
    iconType: '',
    isCloseable: false,
    onDmTap() {},
    onDmClose() {},
  },
  didMount() {},
  didUpdate() {},
  didUnmount() {},
  methods: {
    onDmTap(e) {
      this.props.onDmTap(e, this);
    },
    onDmClose(e) {
      if (this.data.showNotice) {
        this.setData({
          showNotice: false,
        });
      }
      this.props.onDmClose(e, this);
    }
  },
});
