
Component({
  mixins: [],
  data: {
    $uiName: 'tabs',
  },
  props: {
    className: '',
    itemClassName: '',
    widthType: 'full', // 'full':为父级100%宽度，'auto': 宽度由实际文字和tabs个数撑开决定；
    texts: ['item0','item1','item2'],
    activeIndex: 0,
    onDmItemTap() {}
  },
  // didMount() {},
  // didUpdate() {},
  // didUnmount() {},
  methods: {
    onDmItemTap(e) {
      if (!this.props.disabled) {
        const index = e && e.target && e.target.dataset && e.target.dataset.index
        this.props.onDmItemTap(index);
      }
    }
  },
});
