
Component({
  mixins: [],
  data: {
    $uiName: 'switch',
    _checked: false,
  },
  props: {
    className: '',
    checked: false,
    disabled: false,
    dmData: {},
    isControlled: false,
    onDmChange() {},
  },
  didMount() {
    this.setData({
      _checked: this.props.checked
    });
  },
  didUpdate(prevProps,prevData) {
    if (prevProps.checked != this.props.checked && this.props.checked != this.data._checked) {
      this.setData({
        _checked: this.props.checked
      })
    }
  },
  didUnmount() {},
  methods: {
    onDmTap(e) {
      const { disabled, isControlled } = this.props;
      if (disabled) {
        return;
      }
      let checked = this.data._checked;
      if (!isControlled) {
        checked = !checked;
        this.setData({
          _checked: checked
        });
      }
      this.props.onDmChange({
        checked,
        dmData: this.props.dmData,
      });
    }
  },
});
