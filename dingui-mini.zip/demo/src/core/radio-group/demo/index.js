
Component({
  mixins: [],
  data: {
    $uiName: 'radio-group',
    radioListsData: [],
    disabledChecked: false,
  },
  props: {
    className: '',
    radioLists: [],
    radioListsId: '',
    defaultValue: '',
    disabled: '',
    value: '',
    hasArrowIcon: false,
    onDmChange() {},
    onDmExtraClick() {}
  },
  didMount() {
    this.initData()
  },
  didUpdate(preProps) {
    const { 
      radioListsId, 
      defaultValue,
      value
    } = this.props;

    if (preProps.radioListsId !== radioListsId || 
    defaultValue !== preProps.defaultValue ||
    value !== preProps.value) {
      this.initData();
    }
  },
  didUnmount() {},
  methods: {
    initData() {
      const { 
        radioLists, 
        defaultValue,
        value
      } = this.props;
      if (!radioLists.length) {
        return;
      }
      // 如果没有被选中的，先和 defaultValue 比较看有没有默认被选中的，如果都没有没有则选中第一个
      let checkedLists = radioLists.filter((item) => {
        item.isChecked = false;
        return item.value === (value || defaultValue);
      })
      if (checkedLists.length) {
        checkedLists[0].isChecked = true
      } else {
        radioLists[0].isChecked = true
        checkedLists = radioLists[0];
      }

      this.setData({
        radioListsData: radioLists
      })
    },
    onDmChange(data, index, t) {
      const { 
        disabled
      } = this.props;
      const currData = this.data.radioListsData;
      if (disabled || currData[index].disabled || currData[index].isChecked) {
        return;
      }
      currData.forEach((item, idx) => {
        if (index === idx) {
          item.isChecked = !item.isChecked;
        } else {
          item.isChecked = false;
        }
      });
      this.setData({
        radioListsData: currData
      })
      this.props.onDmChange(currData[index].value, index, data, t, this);
    },
    onDmExtraClick(data, index, t) {
      this.props.onDmExtraClick && this.props.onDmExtraClick(this.props.radioLists[index].value, index, data, t, this)
    }
  },
});
