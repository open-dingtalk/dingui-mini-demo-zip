
Component({
  mixins: [],
  data: {
    $uiName: 'button'
  },
  props: {
    className: '',
    type: 'default',//primary|default|danger|primary-ghost|default-light
    disabled: false,
    size: 'default',//"large"|"default"|"small"
    loading: false,
    openType: '',
    formType: '',
    onDmTap() {},
    onDmTapDisabled() {},
    onDmCatchTap: null
  },
  didMount() {},
  didUpdate() {},
  didUnmount() {},
  methods: {
    onDmTap(e) {
      if (this.props.disabled) {
        this.props.onDmTapDisabled(e,this);
        return false;
      }
      if (this.props.loading) {
        return false;
      }
      this.props.onDmTap(e,this);
    },
    onDmCatchTap(e) {
      if (this.props.onDmCatchTap) {
        if (this.props.disabled) {
          this.props.onDmTapDisabled(e,this);
          return false;
        }
        if (this.props.loading) {
          return false;
        }
        this.props.onDmCatchTap(e,this);
      }
    }
  },
});
