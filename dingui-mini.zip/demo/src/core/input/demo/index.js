
Component({
  mixins: [],
  data: {
    $uiName: 'input',
    focus: false,
    valueholder: ''
  },
  props: {
    className: '',
    dmId: 'input',
    name: '',
    title: 'title',
    maxlength: '',
    autoHeight: true,
    placeholder: '',
    autoClear: false,
    value: '',
    type: 'text',//类型 text|multiline|number
    password: false,
    disabled: false,
    error: false,
    errorText: 'error',
    focus: false,
    required: false,
    onDmBlur() {},
    onDmInput() {},
    onDmFocus() {},
    onDmTap() {},
    onDmConfirm() {},
    onDmClear() {},
    onDmValidate: null
  },
  didMount() {
    this.setData({
      focus: this.props.focus,
      valueholder: this.props.value
    })
  },
  didUpdate(prevProps,prevData) {
    if (this.props.focus != prevProps.focus && this.props.focus != this.data.focus) {
      this.setData({
        focus: this.props.focus
      })
    }
    if (this.props.value != prevProps.value && this.props.value != this.data.valueholder) {
      this.setData({
        valueholder: this.props.value
      })
    }
  },
  methods: {
    onDmFocus(e) {
      if (this.props.onDmValidate) {
        this.setData({
          focus: true,
          error: false
        })
      } else {
        this.setData({
          focus: true
        })
      }
      this.props.onDmFocus(e,this);
    },
    onDmBlur(e) {
      const { value } = e.detail;
      if (this.props.onDmValidate) {
        const error = !this.props.onDmValidate(value,this.props);
        this.setData({
          focus: false,
          error
        })
      } else {
        this.setData({
          focus: false
        })
      }
       
      this.props.onDmBlur(e,this);
      //this.triggerEvent('eventBlur', e);
    },
    onDmInput(e) {
      this.setData({
        valueholder: e.detail.value
      })
      // this.triggerEvent('eventInput', e);
      this.props.onDmInput(e,this);
    },
    onDmTap(e) { 
      if (!this.data.valueholder && !this.props.placeholder && !this.data.focus) {
        this.setData({
          focus: true
        })
      }
      this.props.onDmTap(e,this);
    },
    onDmConfirm(e) {
      this.props.onDmConfirm(e,this);
    },
    onDmClearHook(e) {
      this.props.onDmClear(e,this);
      this.setData({
        valueholder: '',
        focus: true
      })
    }
  }
});
