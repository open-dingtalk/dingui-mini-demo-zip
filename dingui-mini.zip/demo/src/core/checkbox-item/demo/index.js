
Component({
  mixins: [],
  data: {
    $uiName: 'checkbox-item'
  },
  props: {
    className: '',
    arrowType: '',
    arrowSize: '',
    isChecked: false, // 是否选中状态，默认不选中
    itemName: '单行列表',
    disabled: false,
    hasArrowIcon: false, // 是否有右侧图标
    index: 0,
    data: null,
    onDmChange() {},
    onDmExtraClick() {},
    onDmTap() {},
  },
  didMount() {},
  didUpdate() {},
  didUnmount() {},
  methods: {
    onDmChange() {
      this.props.onDmChange(this.props.data ,this.props.index, this, this.props.isChecked);
    },
    onDmExtraClick() {
      this.props.onDmExtraClick(this.props.data ,this.props.index, this, this.props.isChecked);
    }
  },
});
