
Component({
  mixins: [],
  data: {
    $uiName: 'list'
  },
  props: {
    className: '',
    onDmTap() {},
  },
  didMount() {},
  didUpdate() {},
  didUnmount() {},
  methods: {
    onDmTap(e) {
      this.props.onDmTap(e,this);
    }
  },
});
