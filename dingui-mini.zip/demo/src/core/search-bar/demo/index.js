import debounce from './debounce';

Component({
  data: {
    $uiName: 'search-bar',
    $cssName: 'dm-search-bar',
    value: '',
    focus: false,
  },
  props: {
    className: '',
    value: '',
    name: '',
    placeholder: '',
    disabled: false,
    maxlength: 140,
    focus: false,
    onDmInput() {},
    onDmConfirm() {},
    onDmFocus() {},
    onDmBlur() {},
    onDmClear() {},
  },
  didMount() {
    //  mapPropsToMethods
    Object.keys(this.props).forEach((fn) => {
      (typeof this.props[fn] === 'function') &&  (this[fn] = this.props[fn])
    })
    this.setData({ value: this.props.value,focus: this.props.focus });
  },
  didUpdate(prevProps) {
    const { focus , value } = this.props;

    // console.log(  'prevProps.value:',prevProps.value,' to ', value);
    const changeData = {};
    let hasChaged  = false;

    if (value !== prevProps.value) {
      changeData.value = value;
      hasChaged = true;
    }
    if (focus !== prevProps.focus) {
      changeData.focus = focus;
      hasChaged = true;
    }
    
    if (hasChaged) {
      this.setData(changeData);
    }
  },
  methods: {

    onDmInputDebounceHook: debounce(function (e) { this.onDmInputHook(e) }, 300),
    onDmInputHook(e) {
      this.props.onDmInput(e);
      this.setData({ value: e.detail.value })
    },

    onDmClearHook() {
      !this.props.disabled && this.setData({ value: '',focus: true },() => {
        this.props.onDmClear({ type: 'clear' });
      })
    }
  },
});
