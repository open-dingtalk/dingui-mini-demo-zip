
Component({
  mixins: [],
  data: {
    $uiName: 'checkbox-group',
    checkboxListsData: []
  },
  props: {
    className: '',
    checkboxLists: [],
    checkboxListsId: '',
    defaultValue: [],
    disabled: '',
    value: [],
    onDmChange() {},
  },
  didMount() {
    this.initData()
  },
  didUpdate(preProps) {
    const {
      checkboxListsId,
      defaultValue,
      value
    } = this.props;
    if (checkboxListsId !== preProps.checkboxListsId ||
    defaultValue !== preProps.defaultValue || 
    value !== preProps.value) {
      this.initData()
    }
  },
  didUnmount() {},
  methods: {
    initData() {
      const { 
        checkboxLists, 
        defaultValue,
        value
      } = this.props;
      if (!checkboxLists.length) {
        return;
      }

      // 首选 value ，次选 defaultValue
      let currVal = [];
      if (value && value.length) {
        currVal = value;
      } else if (defaultValue && defaultValue.length) {
        currVal = defaultValue;
      }
      
      checkboxLists.forEach((item) => {
        if (currVal.indexOf(item.value) !== -1) {
          item.isChecked = true;
        } else {
          item.isChecked = false;
        }
      })

      this.setData({
        checkboxListsData: checkboxLists
      })
    },
    onDmChange(data, index, t) {
      const { 
        disabled
      } = this.props;
      const currData = this.data.checkboxListsData || [];
      // 如果是禁用状态
      if (disabled || currData[index].disabled) {
        return;
      }

      currData[index].isChecked = !currData[index].isChecked;

      const currVal = [];
      currData.forEach((item) => {
        item.isChecked && currVal.push(item.value);
      })

      this.setData({
        checkboxListsData: currData
      })
      this.props.onDmChange(currVal, currData[index].value, index, data, t, this);
    }
  },
});
