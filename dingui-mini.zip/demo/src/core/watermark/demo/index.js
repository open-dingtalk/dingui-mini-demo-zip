
/**
 * props 参数表
 * @param markers string[] 需要展示的水印，默认['水印文字']
 * @param show boolean 是否展示水印，默认true
 * @param slotWidth number 默认375
 */
const acos30 = 1.732;
const asin30 = 2;
const charSize = 6.5 * 3;
const margin = 80 * 3;
Component({
  mixins: [],
  data: {
    $uiName: 'watermark',
    watermarkPaht: '',
    width: 1000,
    height: 1000
  },
  props: {
    className: '',
    markers: ['水印文字'],
    show: true,
    slotWidth: 375,
    backgroundColor: '#FFFFFF'
  },
  didMount() {
    const { markers } = this.props;
    const standarMarkers = this.formatMarker(markers);
    const longestMark = this.getLongestMark(standarMarkers);
    this.setData({
      width: longestMark * charSize / asin30 * acos30 + margin,
      height: this.getCharLength(standarMarkers[0]) * charSize / asin30 + (margin * (standarMarkers.length - 1)) + charSize * 5
    }, () => {
      const ctx = dd.createCanvasContext('canvas');
      this.ctx = ctx;
      ctx.setFillStyle('rgba(25,31,37,0.04)');
      ctx.setFontSize(charSize * 2);
      this.writeMark(standarMarkers);
      ctx.setFillStyle('rgba(255,255,255,0.12)');
      this.writeMark(standarMarkers);
      ctx.draw();
      ctx.toTempFilePath({
        success: (path) => {
          this.setData({
            watermarkPaht: path.filePath
          })
        },
      });
    })
  },
  methods: {
    getLongestMark(markers) {
      const markersLength = markers.map(mark => this.getCharLength(mark));
      markersLength.sort((pre, next) => pre - next);
      return markersLength.pop();
    },
    getCharLength(str) {
      let totalCount = 0;
      for (let i = 0; i < str.length; i++) {
        const c = str.charCodeAt(i);
        if ((c >= 0x0001 && c <= 0x007e) || (c >= 0xff60 && c <= 0xff9f)) {
          totalCount += 1;
        } else {
          totalCount += 2;
        }
      }
      return totalCount;
    },
    writeMark(markers) {
      const { ctx } = this;
      const startY = this.getCharLength(markers[0]) * charSize / asin30 + charSize * 2;
      markers.forEach((mark, i) => {
        ctx.translate(10, startY + i * margin);
        ctx.rotate(-30 * Math.PI / 180);
        ctx.fillText(mark, 0, 0);
        ctx.rotate(30 * Math.PI / 180);
        ctx.translate(-10, -(startY + i * margin));
      })
    },
    formatMarker(markers) {
      return markers && markers instanceof Array ? markers.map((marker) => {
        if (this.getCharLength(marker) > 30) {
          // console.warn(`@ali/dingui-mini:【watermark】expected every string no longer than 30 chars, but recieved string as '${marker}'`);
          let str = '';
          marker.split('').some((char) => {
            if (this.getCharLength(str + char) <= 30) {
              str += char;
              return false;
            } else {
              return true;
            }
          });
          return str;
        } else {
          return marker
        }
      }) : ['']
    }
  }
});
