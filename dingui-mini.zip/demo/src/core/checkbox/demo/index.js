
Component({
  mixins: [],
  data: {
    $uiName: 'checkbox'
  },
  props: {
    className: '',
    isChecked: false,
    size: 44,
    disabled: false,
    onDmChange() {}    
  },
  didMount() {},
  didUpdate() {},
  didUnmount() {},
  methods: {
    onDmChange(e) {
      if (this.props.disabled) {
        return;
      }
      this.props.onDmChange(e,this);
    }
  },
});
