import compI18n from './compI18n.min.js';

Component({
  mixins: [],
  data: {
    uiName: 'empty',
    describeArr: []
  },
  props: {
    className: '',
    locale: 'zh_CN', // en_US | zh_CN | zh_TW | zh_HK | ja_JP | ne_NP | th_TH | vi_VN | jd_ID
    type: 'default', // network|permission|exception|default|''
    img: '',
    iconType: 'search',
    title: '',
    describe: '', // 支持自定义折行 在折行地方加入 <br/> 即可，只能最多在文中插入一个
    btnName: '',
    linkText: '',
    onDmEmptyLinkTap() {}, // 链接点击事件
    onDmEmptyBtnTap() {}, // button点击事件
  },
  didMount() {
    this.initData();
  },
  didUpdate(prevProps) {
    const { type, locale, describe } = this.props;
    if (type !== prevProps.type || locale !== prevProps.locale || describe !== prevProps.describe) {
      this.initData();
    }
  },
  didUnmount() {},
  methods: {
    onDmEmptyBtnTap(e) {
      this.props.onDmEmptyBtnTap(e, this);
    },
    onDmEmptyLinkTap(e) {
      this.props.onDmEmptyLinkTap(e, this);
    },
    getEmptyPagePreset(type) {
      const EmptyPagePreset = {
        'network': {
          img: 'https://gw.alicdn.com/tfs/TB1fBxMRrvpK1RjSZFqXXcXUVXa-543-360.png',
          describe: compI18n.t('dingui_mini_network_connection_error'),
          linkText: compI18n.t('dingui_mini_view_network_diagnostics'),
          btnName: compI18n.t('dingui_mini_retry')
        },
        'permission': {
          img: 'https://gw.alicdn.com/tfs/TB1lT0QRq6qK1RjSZFmXXX0PFXa-543-360.png',
          describe: compI18n.t('dingui_mini_permission_error'),
        },
        'exception': {
          img: 'https://gw.alicdn.com/tfs/TB1e8xMRrvpK1RjSZFqXXcXUVXa-543-360.png',
          describe: compI18n.t('dingui_mini_page_error'),
          btnName: compI18n.t('dingui_mini_refresh')
        }
      }
      return type ? EmptyPagePreset[type] : EmptyPagePreset;
    },
    initData() {
      const { type, locale, describe } = this.props;
      compI18n.setLng(locale);
      if (describe && describe.indexOf('<br/>') != -1) {
        this.setData({
          describeArr: describe.split('<br/>').slice(0,2)
        })
      }
      if (Object.prototype.hasOwnProperty.call(this.getEmptyPagePreset(), type)) {
        const langResource = this.getEmptyPagePreset(type) || {};
        this.setData({
          img: langResource.img || '',
          title: langResource.title || '',
          describe: langResource.describe || '',
          btnName: langResource.btnName || '',
          linkText: langResource.linkText || ''
        });
      }
    },
  },
});
