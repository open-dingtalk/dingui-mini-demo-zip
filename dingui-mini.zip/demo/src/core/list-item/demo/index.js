
Component({
  mixins: [],
  data: {
    $uiName: 'list-item',
    selected: false,
  },
  props: {
    className: '',
    captionClassName: '', // 控制标题样式
    dmId: '', 
    disabled: false,
    
    //checkbox配置
    checkable: false, //是否显示checkbox
    checked: false, //默认选中状态
   

    //thumb
    thumbClassName: '',
    thumbSize: 'standard', // mini(48rpx)、standard(72rpx)、big(96rpx)、large(112rpx)
    thumbType: 'circle', //circle、square
    thumbUrl: '',
    thumbVTop: false,

    //extra
    extraClassName: '',
    extraVTop: false,
    extraText: '',

    //badge
    badgeShow: false,
    badgeText: '',


    // arrow，查看wings-icon
    arrowClassName: '',
    arrowType: '',//icon的type
    arrowSize: 'small', //查看wings-icon的size

    briefClassName: '',
    briefList: [],
    //border-bottom
    hasborder: false,//强制设置border
    noborder: false,//强制隐藏border

    onDmTap() {},
    onDmChange() {},
    onDmArrowClick: null,
  },
  didMount() {
    const { checked } = this.props;
    this.setData({
      selected: checked
    });
  },
  didUpdate(preProps) {
    const { checked } = this.props;
    if (preProps.checked !== checked) {
      this.setData({
        selected: checked
      })
    }
  },
  didUnmount() {},
  methods: {
    handleCheckboxChange(e) {
      const { onDmChange, dmId } = this.props;
      const { selected } = this.data;
      this.setData({
        selected: !selected
      });
      onDmChange({
        dmId,
        status: !selected
      },e,this);
    },
    // handleArrowTap(e) {
    //   const { dataset } = e.target;
    //   const { dmId } = dataset;
    //   const { onDmArrowClick } = this.props;
    //   onDmArrowClick(dmId,e,this);
    // },
    onDmTap(e) {
      const { dataset } = e.target;
      const { dmId ,type } = dataset;
      const { onDmTap,onDmArrowClick,checkable,disabled } = this.props;
      if (type == 'arrow' && onDmArrowClick) {
        onDmArrowClick(dmId,e,this);
      } else {
        if (checkable && !disabled) {
          this.handleCheckboxChange(e);
        }
        onDmTap(dmId,e,this);
      }
    }
  },
});
