
Component({
  mixins: [],
  data: {
    $uiName: 'affix'
  },
  props: {
    className: '',
    onDmTap() {},
    top: 0,
    bottom: undefined
  },
  didMount() {},
  didUpdate() {},
  didUnmount() {},
  methods: {
    onDmTap(e) {
      this.props.onDmTap(e,this);
    }
  },
});
