Component({
  mixins: [],
  data: {
    $uiName: 'modal',
    inputValueHolder: '',
    activeIndex: -1
  },
  props: {
    className: '',
    show: true,
    topImage: '',
    topImageSize: '', // large || small
    title: '',
    describe: '',
    hasInput: false,
    inputValue: '',
    inputPlaceholder: '',
    inputType: 'text',
    inputDisabled: false,
    inputFocus: false,
    inputMaxlength: 140,
    buttonList: [], // {name:"",isMainEvent:""}
    onDmBtnTap: () => {},
    onDmInput: () => {}
  },
  didMount() {
    const { inputValue } = this.props;
    this.setData({
      inputValueHolder: inputValue
    })
  },
  didUpdate(prevProps,prevData) {
    const { inputValue, hasInput } = this.props;
    if (hasInput && inputValue != prevProps.inputValue) {
      this.setData({
        inputValueHolder: this.props.inputValue
      })
    }
  },
  didUnmount() { },
  methods: {
    onDmBtnTap(e) {
      this.props.onDmBtnTap(e, this);
    },
    onDmClearHook() {
      if (!this.props.inputDisabled) {
        this.setData({ 
          inputValue: '',
          inputFocus: true,
          inputValueHolder: ''
        })
      }
    },
    onDmInput(e) {
      this.setData({
        inputValueHolder: e.detail.value
      })
      this.props.onDmInput(e, this);
    },
    onDmBtnTouchStart(e) {
      const currIndex = e && e.target && e.target.dataset && e.target.dataset.index;
      this.setData({
        activeIndex: currIndex
      });
    },
    onDmBtnTouchEnd(e) {
      this.setData({
        activeIndex: -1
      });
    },
    onDmBtnTouchCancel(e) {
      this.setData({
        activeIndex: -1
      });
    }
  },
});
