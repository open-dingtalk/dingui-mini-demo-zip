
import dmiconfont from './dmiconfont';
import iconResource from './custom';

iconResource.add('dmiconfont', dmiconfont);

const PRESET_SIZE = {
  'small': 32,
  'medium': 48,
  'large': 64,
  'huge': 96,
}

Component({
  data: {
    $uiName: 'icon',

    iconText: '',   //  ICON 名称 对应的文本
    iconSize: '',  //  ICON样式：大小
    iconFont: '',  //  ICON样式：字体
  },

  props: {
    className: '',
    type: '',
    size: 0,      //  ICON大小，允许传入数字，或是 PRESET_SIZE 中预定义的尺寸
    onDmTap() { }
  },

  didMount() {
    this.setIconSize(this.props.size);
    this.setIconFontAndText(this.props.type);
  },

  didUpdate() {
    const { type,size } = this.props;
    if (this.data.type !== type) {
      this.setIconFontAndText(type);
    }
    if (this.data.size !== size) {
      this.setIconSize(size);
    }
  },

  methods: {

    setIconSize(propSize) {
      let iconSize = '';
      let intSize = parseInt(propSize, 10) || 0;
      if (intSize < 1) {
        intSize = PRESET_SIZE[propSize];
      }
      iconSize  =  intSize ? `font-size:${intSize}rpx;` : '';
      this.setData({ iconSize });
    },

    setIconFontAndText(propType) {
      const { type2font,type2text } = iconResource.get();
      if (type2font[propType] === undefined) {
        propType = 'home';
      }
      const iconFont = type2font[propType];
      const iconText = type2text[propType];

      this.setData({ iconFont, iconText });
    },

    onDmTap(e) {
      this.props.onDmTap(e, this);
    }
  }
});
