const isType = (vari, type) => Object.prototype.toString.call(vari) === `[object ${type}]`;

const resource = {
  type2text: {},
  type2font: {},
};

const get = () => resource;

/**
 * 新增一个字体资源
 * @param {String} font 字体的fontFamily
 * @param {Object} icon icon的type映射为content的字典
 */
const add = (font = '', icon = {}) => {
  if (!isType(font, 'String') || !isType(icon, 'Object')) {
    return false;
  }
  Object.keys(icon).forEach((type) => {
    const text = icon[type];
    if (isType(resource.type2text[type], 'Undefined')) {
      resource.type2text[type] = text;
      resource.type2font[type] = font;
    }
  })
  return resource;
}

module.exports = {
  add,
  get,
  set: add  //  兼容之前的 set 写法
}