/**
 * props 参数表
 * @param slotWidth number px单位（ip6设计稿尺寸为准） 判断是否超过48 决定徽标位置
 * @param show boolean 是否展示小红点，默认true
 * @param text string 展示的数字或文案，当为数字时候，大于 overflowCount时显示为 ${overflowCount}+，为 0 时隐藏
 */
Component({
  mixins: [],
  data: {
    $uiName: 'badge',
    dotClass: '',
    textClass: '',
    textStyle: '',
    loading: true
  },
  props: {
    className: '',
    slotWidth: 32,
    text: '',
    show: true
  },
  didMount() {
    if (this.props.text) {
      this.setTextType();
    }
    this.setExtraContentClass();
  },
  didUpdate(preProps) {
    if (this.props.text && preProps.text !== this.props.text) {
      this.setTextType();
    }
    if (preProps.dotClass !== this.props.dotClass || preProps.textClass !== this.props.textClass || preProps.loading !== this.props.loading) {
      this.setExtraContentClass();
    }
  },
  methods: {
    setTextType() {
      this.setData({
        textTypeClass: Number.parseInt(this.props.text) ? 'dm-badge-text-number' : 'dm-badge-text-char'
      })
    },
    setExtraContentClass() {
      let dotClass = '';         
      let textClass = ''; 
      let slotWidth = 48;
      try {
        slotWidth = parseInt(this.props.slotWidth, 10);
      } catch (e) {
        slotWidth = 48;
      }
      if (this.props.slotWidth) {
        dotClass = slotWidth < 48 ? 'dm-badge-dot-corner-small' : 'dm-badge-dot-corner-big';
        textClass = slotWidth < 48 ? 'dm-badge-text-corner-small' : 'dm-badge-text-corner-big';
      }
      if (this.props.text) {
        textClass += ` ${this.props.text.length > 1 ? 'dm-badge-m' : 'dm-badge-s'}`
      }
      this.setData({
        dotClass,
        textClass,
        loading: false
      })
    }
  },
});
