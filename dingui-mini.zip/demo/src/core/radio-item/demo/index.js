
Component({
  mixins: [],
  data: {
    $uiName: 'radio-item',
  },
  props: {
    className: '',
    arrowType: 'details',
    arrowSize: 'medium',
    isChecked: false, // 是否选中状态，默认不选中
    itemName: '单行列表',
    disabled: false,
    hasArrowIcon: false, // 是否有右侧图标
    index: 0,
    data: null,
    onDmChange() {},
    onDmExtraClick() {},
  },
  didMount() {},
  didUpdate() {},
  didUnmount() {},
  methods: {
    onDmChange(e) {
      this.props.onDmChange(this.props.data ,this.props.index, this, this.props.isChecked);
    },
    onDmExtraClick(e) {
      this.props.onDmExtraClick(this.props.data ,this.props.index, this, this.props.isChecked);
    }
  },
});
