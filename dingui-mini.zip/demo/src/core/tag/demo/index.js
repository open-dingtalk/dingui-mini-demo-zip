
Component({
  mixins: [],
  data: {
    $uiName: 'tag',
    checked: false,
    closed: false
  },
  props: {
    className: '',
    text: '',
    type: 'blue',//blue,red,green,orange,darkblue,gray,darkgray,darkorange,darkred
    size: 'small',//large,small
    closable: false,
    data: null,
    autoChecked: false,
    checked: false,
    onDmTap() {},
    onDmChange() {},
    onDmClose() {}
  },
  didMount() {
    this.setData({
      checked: this.props.checked
    })
  },
  didUpdate(prevProps) {
    if (prevProps.checked !== this.props.checked) {
      this.setData({
        checked: this.props.checked
      })
    }
  },
  didUnmount() {},
  methods: {
    onDmTap(e) {
      if (this.props.autoChecked && !this.data.closed) {
        this.setData({
          checked: !this.data.checked
        },() => {
          this.props.onDmChange(this.data.checked,this.props.data);
        })
      }
    },
    onDmClose(e) {
      if (this.props.closable) {
        this.setData({
          closed: true
        },() => {
          if (this.props.autoChecked) {
            this.props.onDmChange(false,this.props.data);
          }
          this.props.onDmClose(this.props.data);
        })
      }
    }
    
  },

});
