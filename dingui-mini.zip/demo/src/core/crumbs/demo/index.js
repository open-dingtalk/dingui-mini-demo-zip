
Component({
  mixins: [],
  data: {
    $uiName: 'crumbs',
  },
  props: {
    className: '',
    /** 面包屑导航数据集 */
    breadcrumbs: [],
    onDmCrumbsTap() {},
  },
  didMount() {},
  didUpdate() {},
  didUnmount() {},
  methods: {
    onDmTap(e) {
      const { index } = e.target.dataset;
      // 最后一项即当前页面，没有导航
      if (index !== this.props.breadcrumbs.length - 1) {
        this.props.onDmCrumbsTap(e, this, index);
      }
    }
  },
});
