
Component({
  mixins: [],
  data: {
    $uiName: 'segmented-control',
  },
  props: {
    className: '',
    itemClassName: '',
    widthType: 'auto', // 'auto':宽度尽量小，由文字撑开；'full':为父级100%宽度
    texts: ['item0','item1'],
    activeIndex: 0,
    disabled: false,
    onDmItemTap() {},
    onDmDisabledItemTap() {}
  },
  // didMount() {},
  // didUpdate() {},
  // didUnmount() {},
  methods: {
    onDmItemTap(e) {
      const index = e && e.target && e.target.dataset && e.target.dataset.index
      this.props[this.props.disabled ? 'onDmDisabledItemTap' : 'onDmItemTap'](index);
    }
  },
});
