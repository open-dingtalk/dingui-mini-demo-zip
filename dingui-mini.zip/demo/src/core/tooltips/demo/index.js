Component({
  timeId: 0,
  data: {
    $uiName: 'tooltips',
    $cssName: 'dm-tooltips',

    visible: false,
    disappear: false,
    textWidth: undefined,
    arrowOffset: 0,
  },
  props: {
    placement: 'top',       //  top left right bottom topLeft topRight bottomLeft bottomRight leftTop leftBottom rightTop rightBottom
    visible: false,
    className: '',
    textWidth: undefined,   //  tooltips 中文案文字宽度（最大480，可以用于控制显示行数）
    slotWidth: 0,           //  tooltips 包住的内容区域宽度（用于三角标定位到正中）
    animate: false,       //  是否开启动画，默认否
    onDmClose() { }
  },
  didMount() {
    //  优化，支持回调
    this.adjustArrowOffset(({ arrowOffset }) => {
      const data = { visible: this.props.visible ,arrowOffset };
      this.setData(data);
    });
  },
  didUpdate(preProps) {
    // 显示位置，内容尺寸，文本尺寸未发生变化时
    const hasChanged = {
      placement: preProps.placement !== this.props.placement,
      slotWidth: preProps.slotWidth !== this.props.slotWidth,
      textWidth: preProps.textWidth !== this.props.textWidth
    }
    if (hasChanged.placement || hasChanged.slotWidth || hasChanged.textWidth) {
      // console.log({hasChanged})
      this.adjustArrowOffset(({ arrowOffset }) => {
        this.setData({ arrowOffset })
      });
    }

    const from = preProps.visible;
    const to = this.props.visible;
    // console.log({from,to})
    //  防止更新过程中 props 反复传入(导致状态会强制和props一致)
    if (from === to) {
      return false;
    }
    this.toggleDisplay(to);
  },
  methods: {

    /**
     * 关闭按钮点击
     */
    onDmCloseHook() {
      // this.setData({ visible: false }, () => false&&)
      this.toggleDisplay(false, () => this.props.onDmClose());
    },

    /**
     * 切换 tooltips 展现or隐藏
     * @param {boolean} visible 是否展现
     * @param {function} callback 执行完操作之后的回调
     */

    toggleDisplay(visible = true, callback) {
      if (visible === this.data.visible) {
        return false;
      }
      // console.log('toggleDisplay',{from:this.data.visible,to:visible},)
      if (visible) {
        //  hidden -> show（需先恢复节点） 
        this.setData({ disappear: false }, () => {
          clearTimeout(this.timeId)
          this.timeId = setTimeout(() => this.setData({ visible: true }, () => callback && callback()), 50);
        });
      } else {
        //  show - hidden（动画结束后删除节点） 
        this.setData({ visible }, () => {
          clearTimeout(this.timeId)
          this.timeId = setTimeout(() => this.setData({ disappear: true }, () => callback && callback()), 650);
        });
      }
    },

    /**
     * 计算箭头的位置和间距
     * @todo 支持callback
     */
    adjustArrowOffset(callback) {
      const { placement } = this.props;
      const { slotWidth } = this.props;
      const isCenter = ['left', 'right', 'top', 'bottom'].indexOf(placement) > -1;
      if (isCenter) {
        return callback({ arrowOffset: 0 })
      }
      //  判断是否没有移动

      const multiplier = placement.indexOf('Left') > -1 ? -1 : 1; //  减掉 arrow 宽度的一般 ， 最多是标题文本的 50% 宽度（超过了就该换边啦）
      const arrowOffset = Math.min(Math.max(Math.floor(slotWidth / 2 - 12), 5), Math.floor(this.props.textWidth / 2)) * multiplier;
      return callback({ arrowOffset })
    }

  }
});
