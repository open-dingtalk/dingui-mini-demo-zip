
Component({
  mixins: [],
  data: {
    $uiName: 'screen'
  },
  props: {
    className: '',
    dmId: '',
    item: [],
    autoSelect: true,
    selectList: [],
    style: 'default',
    type: 'checkbox',//checkbox 多选，radio 单选---只有在autoSelect生效时有意义
    onDmChange() {},
  },
  didMount() {
    this.setData({
      selectList: this.props.selectList
    })
  },
  didUpdate(preProps) {
    if (JSON.stringify(this.props.selectList) !== JSON.stringify(preProps.selectList)) {
      this.setData({
        selectList: this.props.selectList
      })
    }
  },
  didUnmount() {},
  methods: {
    changeState(e) {
      const { index,option } = e.target.dataset;
      option.index = index;
      if (option.id === undefined) {
        option.id = `screen${this.props.dmId}${index}`;
      }
      if (this.props.autoSelect) {
        if (this.props.type == 'radio') {
          this.setData({
            selectList: [option.id]
          },() => {
            this.props.onDmChange(option,this.data.selectList,this);
          })
        } else if (this.data.selectList.indexOf(option.id) === -1) {
          this.$spliceData({
            selectList: [0,0,option.id]
          },() => {
            this.props.onDmChange(option,this.data.selectList,this);
          })
        } else {
          this.setData({
            selectList: this.data.selectList.filter(item => item != option.id)
          },() => {
            this.props.onDmChange(option,this.data.selectList,this);
          })
        }
      } else {
        this.props.onDmChange(option,this.data.selectList,this);
      }
    }
  },
});
