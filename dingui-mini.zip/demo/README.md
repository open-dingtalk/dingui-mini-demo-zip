# dingui-mini

## 钉钉小程序标准组件库核心库

* 1.3.0 新增固钉和塞选组件，tag组件的样式更新，以及list组件arrow区域点击范围增大
* 1.2.0 新增水印和顶部通知组件，修复tag组件的一些bug，以及list组件brief区域右侧间距问题
* 1.1.1 修复了list的disabled效果
* 1.1.0
  1.新增tag，radio-item，radio-group，checkbox，checkbox-item，checkbox-group组件
  2.新增weex化组件：分段器，通知栏，面包屑，tag
  3.button 在部分安卓下的边框显示bug修复，新增catchTap
  4.listweex化下支持了按下效果
* 1.0.0-beta.8 list/icon/switch weex版本
* 1.0.0 第一版
* 0.0.1 项目初始化
