 module.exports = [
        {
          title: '控件',
          cardList:[
        {
          name: '字体',
          enname: 'font',
          link: '/src/demo/font/font'
        },
        {
          name: '颜色',
          enname: 'color',
          link: '/src/demo/color/color'
        },
        {
          name: '图标',
          enname: 'icon',
          id:'icon',
          link: '/src/core/icon/demo/index'
        },
        {
          name: '按钮',
          enname: 'button',
          id:'button',
          link: '/src/core/button/demo/index'
        },
        {
          name: '引导气泡',
          enname: 'tooltips',
          id:'tooltips',
          link: '/src/core/tooltips/demo/index'
        },
        {
          name: '标签',
          enname: 'tag',
          id:'tag',
          link: '/src/core/tag/demo/index'
        }]
      },
      {
        title: '基础组件',
        cardList: [
      {
        name: '列表',
        enname: 'list',
        id:['list','list-item'],
        link: '/src/core/list/demo/index'
      },
      {
        name: '单选',
        enname: 'radio-group/radio-item',
        id:['radio-group','radio-item'],
        link: '/src/core/radio-group/demo/index'
      },
      {
        name: '多选',
        enname: 'checkbox-group(item)/checkbox',
        id:['checkbox-group','checkbox-item','checkbox'],
        link: '/src/core/checkbox-group/demo/index'
      },
      {
        name: '输入框',
        enname: 'input',
        id:'input',
        link: '/src/core/input/demo/index'
      },
      {
        name: '选项卡',
        enname: 'tabs',
        id:'tabs',
        link: '/src/core/tabs/demo/index'
      },
      {
        name: '红点',
        enname: 'badge',
        id:'badge',
        link: '/src/core/badge/demo/index'
      },
      {
        name: '分段器',
        enname: 'segmented-control',
        id:'segmented-control',
        link: '/src/core/segmented-control/demo/index'
      },
      {
        name: '搜索栏',
        enname: 'search-bar',
        id:'search-bar',
        link: '/src/core/search-bar/demo/index'
      },
      {
        name: '面包屑',
        enname: 'crumbs',
        id:'crumbs',
        link: '/src/core/crumbs/demo/index'
      },
      {
        name: '通告栏',
        enname: 'notice-bar',
        id:'notice-bar',
        link: '/src/core/notice-bar/demo/index'
      },
      {
        name: '筛选组件',
        enname: 'screens',
        id:'screens',
        link: '/src/core/screens/demo/index'
      }
        ]
      },
      {
        title: '操作反馈',
        cardList: [
          {
            name: '弹窗',
            enname: 'modal',
            id: 'modal',
            link: '/src/core/modal/demo/index'
          },{
            name: '开关',
            enname: 'switch',
            id: 'switch',
            link: '/src/core/switch/demo/index'
          },{
            name: '顶部通知',
            enname: 'message',
            link: '/src/core/message/demo/index'
          }
        ]
      },
      {
        title: '页面相关',
        cardList: [
          {
            name: '空页面',
            enname: 'empty',
            id: 'empty',
            link: '/src/core/empty/demo/index'
          },{
            name: '水印',
            enname: 'watermark',
            id: 'watermark',
            link: '/src/core/watermark/demo/index'
          },{
            name: '固钉',
            enname: 'affix',
            id: 'affix',
            link: '/src/core/affix/demo/index'
          }
        ]
      }
    ]